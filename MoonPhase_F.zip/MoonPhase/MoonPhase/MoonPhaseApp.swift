//
//  MoonPhaseApp.swift
//  MoonPhase
//
//  Created by student on 07/05/2024.
//

import SwiftUI

@main
struct MoonPhaseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
